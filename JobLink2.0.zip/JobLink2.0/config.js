window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "WilsonCO JobLink",
   "homepage": "https://htmlpreview.github.io/?https://github.com/wicorn29/WilsonFilms_SERVER-MAIN/blob/main/PWFIndex.html",
   "enableNavBttns": false,
   "enableHomeBttn": false,
   "enableReloadBttn": false,
   "enableLogoutBttn": false,
   "rotation": "0",
   "kioskEnabled": false
};